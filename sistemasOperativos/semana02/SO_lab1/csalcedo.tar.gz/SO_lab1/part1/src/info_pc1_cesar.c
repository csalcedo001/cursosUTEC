#include "printInfo.h"

int main (void) {
	printCPUName();
	printMemory();
	printKernelVersion();
	printUpTime();
	
	return 0;
}
