#ifndef PRINT_INFO_C
#define PRINT_INFO_C

#include "fileSearch.h"

void printCPUName();
void printMemory();
void printKernelVersion();
void printUpTime();

#endif
