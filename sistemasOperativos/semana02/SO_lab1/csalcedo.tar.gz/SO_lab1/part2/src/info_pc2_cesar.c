#include "printInfo.h"

int main (void) {
	printFreeMemory();
	printModeTime();
	printSwitches();
	
	return 0;
}
